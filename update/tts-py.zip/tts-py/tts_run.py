#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Standalone Edge TTS runner for 培基智多星 receiver (local voice service).
Produces an MP3 (24kHz/48kbps CBR mono) matching the built-in audio library spec.
Contract with PowerShell caller:
  exit 0 + stdout JSON   -> {"src":"edge","dur_s":<float>,"bytes":<int>}
  exit 2 + TTS_ERROR_EMPTY -> synthesis returned nothing
  exit 3 + stderr snippet  -> fatal (missing module / network / unexpected)
stdout first line is always the JSON / error token (UTF-8).
"""
import argparse, asyncio, json, sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--text", default="")
    ap.add_argument("--out", default="")
    ap.add_argument("--en", type=int, default=0)
    ap.add_argument("--voice", default="")
    ap.add_argument("--rate", default="-10%")
    args = ap.parse_args()
    text = args.text.strip()
    if not text:
        print("TTS_ERROR_EMPTY"); return 2
    out = args.out.strip()
    if not out:
        print("TTS_ERROR_NOOUT"); return 2
    voice = args.voice or ("en-US-JennyNeural" if args.en else "zh-CN-XiaoxiaoNeural")

    try:
        import edge_tts
    except Exception as e:
        sys.stderr.write("no_edge_tts " + repr(e)[:200]); return 3

    async def _stream():
        comm = edge_tts.Communicate(text, voice, rate=args.rate)
        buf = b""
        async for chunk in comm.stream():
            if chunk.get("type") == "audio":
                buf += chunk["data"]
        return buf

    try:
        data = asyncio.run(asyncio.wait_for(_stream(), timeout=25))
    except Exception as e:
        sys.stderr.write(repr(e)[:300]); return 3
    if not data:
        print("TTS_ERROR_EMPTY"); return 2

    with open(out, "wb") as fh:
        fh.write(data)
    dur = round(len(data) * 8.0 / 48000.0, 2)  # CBR 48kbps estimate
    print(json.dumps({"src": "edge", "dur_s": dur, "bytes": len(data)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())